main(int a, int b) {
    double x;
    x = 2.3;

    double y;
    y = 3.e4;

    double z;
    z = x + y;

    double s;
    s = x - y;

    int k;
    k = 10;

    double c;
    c = z + k;
    
    return(x);
}